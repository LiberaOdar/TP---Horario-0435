//
// Created by cueva on 30/04/2026.
//
#include <iomanip>
#include <iostream>
#include <fstream>
#include "Funciones.h"

using namespace std;

void cargaempresas(int *empdni,const char*nom) {
    int i=0;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout <<"No se puede abrir el archivo "<<nom<<endl;
        exit(1);
    }
    while (true) {
        arch >> empdni[i];
        if (arch.eof())break;
        while (arch.get()!='\n');
        i++;
    }
}

void cargaplacas(int *pladni,char*platipo,int*planum1,int *planum2,
    const char*nom) {
    int i=0;
    char c;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout <<"No se puede abrir el archivo "<<nom<<endl;
        exit(1);
    }
    while (true) {
        arch >> pladni[i];
        if (arch.eof())break;
        arch>>platipo[i]>>planum1[i]>>c>>planum2[i];
        i++;
    }
}

void cargacometidas(char *comtipo,int *comnum1,int *comnum2,
    char *comgravedad,int *comcodinf,const char*nom) {
    int i=0,dd,mm,aa;
    char c;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout <<"No se puede abrir el archivo "<<nom<<endl;
        exit(1);
    }
    while (true) {
        arch>>dd;
        if (arch.eof())break;
        arch>>c>>mm>>c>>aa>>comtipo[i]>>comnum1[i]>>c>>comnum2[i];
        arch>>comgravedad[i]>>comcodinf[i];
        i++;
    }
}

void cargainfracciones(char *infgravedad,int *infcodinf,
    double  *infcosto,const char*nom) {
    int i=0;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout <<"No se puede abrir el archivo "<<nom<<endl;
        exit(1);
    }
    while (true) {
        arch >> infgravedad[i];
        if (arch.eof())break;
        arch>>infcodinf[i]>>infcosto[i];
        while (arch.get()!='\n');
        i++;
    }

}

void emitereporte(int *empdni,int *pladni,int *planum1,int *planum2,
    int *comnum1,int *comnum2,int *comcodinf,int *infcodinf,
    char *platipo,char *comtipo,char *comgravedad,char *infgravedad,
    double *infcosto,const char*nom) {

    ofstream arch(nom,ios::out);
    if (not arch.is_open()) {
        cout <<"No se puede abrir el archivo "<<nom<<endl;
        exit(1);
    }
    for (int i=0;empdni[i]!=0;i++) {
        int numleves=0,numgraves=0,nummuygraves=0;
        double costoleves=0,costograves=0,costomuygraves=0;
        arch << "Representante Legal: "<< empdni[i]<<endl;
        for (int j=0;pladni[j]!=0;j++) {
            if (empdni[i]==pladni[j]) {
                buscacalcula(platipo[j],planum1[j],planum2[j],comnum1,comnum2,comcodinf,
                    infcodinf,comtipo,comgravedad,infgravedad,infcosto,
                    numleves,numgraves,nummuygraves,costoleves,costograves,costomuygraves);

            }
        }
        arch<<left<<setw(40)<<"Leves"<<setw(40)<<"Graves"<<setw(40)<<"Muy Graves"<<endl;
        arch<<setw(20)<<"Cantidad"<<setw(20)<<"Total"<<setw(20)<<"Cantidad"<<setw(20)<<"Total"<<setw(20)<<"Cantidad"<<setw(20)<<"Total"<<endl;
        arch<<setw(20)<<numleves<<setw(20)<<costoleves<<setw(20)<<numgraves<<setw(20)<<costograves<<setw(20)<<nummuygraves<<setw(20)<<costomuygraves<<endl<<endl;
    }
}

void buscacalcula(char tipo,int num1,int num2,int *comnum1,int *comnum2,int *comcodinf,int *infcodinf,
    char *comtipo,char *comgravedad,char *infgravedad,double *infcosto,
    int &numleves,int &numgraves,int &nummuygraves,
    double &costoleves,double &costograves,double &costomuygraves) {

    for (int i=0;comnum1[i]!=0;i++) {
        if (tipo==comtipo[i] and num1==comnum1[i] and num2==comnum2[i]) {
            for (int j=0;infcodinf[j]!=0;j++) {
                if (comgravedad[i]==infgravedad[j] and comcodinf[i]==infcodinf[j]) {
                    if (comgravedad[i]=='L') {
                        numleves++;
                        costoleves+=infcosto[j];
                    }
                    if (comgravedad[i]=='G') {
                        numgraves++;
                        costograves+=infcosto[j];
                    }
                    if (comgravedad[i]=='M') {
                        nummuygraves++;
                        costomuygraves+=infcosto[j];
                    }
                }
            }
        }
    }
}


