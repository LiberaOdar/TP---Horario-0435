//
// Created by cueva on 30/04/2026.
//

#ifndef ARREGLOSINFRACCIONES_FUNCIONES_H
#define ARREGLOSINFRACCIONES_FUNCIONES_H
    void cargaempresas(int *empdni,const char*nom);
    void cargaplacas(int *pladni,char*platipo,int*planum1,int *planum2,
        const char*nom);
    void cargacometidas(char *comtipo,int *comnum1,int *comnum2,
        char *comgravedad,int *comcodinf,const char*nom) ;
    void cargainfracciones(char *infgravedad,int *infcodinf,
        double  *infcosto,const char*nom);
    void buscacalcula(char tipo,int num1,int num2,int *comnum1,int *comnum2,int *comcodinf,int *infcodinf,
        char *comtipo,char *comgravedad,char *infgravedad,double *infcosto,
        int &numleves,int &numgraves,int &nummuygraves,
        double &costoleves,double &costograves,double &costomuygraves);
    void emitereporte(int *empdni,int *pladni,int *planum1,int *planum2,
        int *comnum1,int *comnum2,int *comcodinf,int *infcodinf,
        char *platipo,char *comtipo,char *comgravedad,char *infgravedad,
        double *infcosto,const char*nom);

#endif //ARREGLOSINFRACCIONES_FUNCIONES_H