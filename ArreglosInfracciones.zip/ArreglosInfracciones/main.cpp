#include <iostream>

#include "Biblioteca/Funciones.h"

int main() {
    int empdni[100]{},pladni[200]{},planum1[200]{},planum2[200]{};
    int comnum1[700]{},comnum2[700]{},comcodinf[700]{},infcodinf[150]{};
    char platipo[200],comtipo[700],comgravedad[700],infgravedad[150];
    double infcosto[150]{};

    cargaempresas(empdni,"ArchivosIngreso/EmpresasRegistradas.txt");
    cargaplacas(pladni,platipo,planum1,planum2,"ArchivosIngreso/PlacasRegistradas.txt");
    cargacometidas(comtipo,comnum1,comnum2,comgravedad,comcodinf,"ArchivosIngreso/InfraccionesCometidas.txt");
    cargainfracciones(infgravedad,infcodinf,infcosto,"ArchivosIngreso/TablaDeInfracciones.txt");
    emitereporte(empdni,pladni,planum1,planum2,comnum1,comnum2,comcodinf,infcodinf,platipo,comtipo,
        comgravedad,infgravedad,infcosto,"ArchivosSalida/Reporte.txt");

    return 0;
}
