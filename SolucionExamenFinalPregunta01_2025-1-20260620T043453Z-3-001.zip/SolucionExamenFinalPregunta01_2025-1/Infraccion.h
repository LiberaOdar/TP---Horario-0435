// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  Infraccion.h.h
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:43:39.
//

#ifndef INFRACCION_H
#define INFRACCION_H
#include "Fecha.h"

struct Infraccion {
    struct Fecha fecha_infraccion;
    char *codigo;
    char *descripcion;
    char *gravedad;
    double monto;
    int dni_conductor;
};

#endif //INFRACCION_H
