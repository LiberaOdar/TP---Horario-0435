// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  Fecha.h.h
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:40:51.
//

#ifndef FECHA_H
#define FECHA_H

struct Fecha {
    int dd;
    int mm;
    int aa;
    int aammdd;
};

#endif //FECHA_H
