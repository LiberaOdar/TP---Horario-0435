// Proyecto: SolucionExamenFinalPregunta01_2025-1
// Archivo:  
//
// Autor:   J. Miguel Guanira E
// Creado el lunes, 07 de julio del 2025 a las 10:32:18.
// 

#include <iostream>
#include <iomanip>
using namespace std;
#include "Conductor.h"
#include "Vehiculo.h"
#include "Infraccion.h"
#include "FuncionesAuxiliares.h"

int main(int argc, char **argv) {
    struct Conductor *conductores  = new Conductor[120]{};
    struct Vehiculo *vehiculos = new Vehiculo[160]{};
    struct Infraccion *infraciones = new Infraccion[160]{};
    int numCond, numVehic, numInfrac;

    leerConductores("conductores.csv", conductores, numCond);
    // pruebaLecturaConductores(conductores, numCond);
    leerVeiculos("vehiculos.csv", vehiculos, numVehic);
    pruebaLecturaVehiculos(vehiculos, numVehic);
    leerInfracciones("infracciones.csv",infraciones,numInfrac);
    pruebaLecturaInfracciones(infraciones, numInfrac);
    actualizarInformacion(conductores, numCond,vehiculos, numVehic,infraciones, numInfrac);
    pruebaLecturaConductores(conductores, numCond);
    emitirPapeletas(conductores, numCond);
    return 0;
}

