// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  Vehiculo.h.h
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:42:00.
//

#ifndef VEHICULO_H
#define VEHICULO_H

struct Vehiculo {
    int dni_propietario;
    char *placa;
    char *marca_modelo;;
};

#endif //VEHICULO_H
