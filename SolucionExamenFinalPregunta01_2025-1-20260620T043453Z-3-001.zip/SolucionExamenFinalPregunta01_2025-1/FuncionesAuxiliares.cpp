// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  FuncionesAuxiliares.cpp.cpp
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:52:50.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include <bits/unordered_map.h>
using namespace std;
#include <cstring>
#include "FuncionesAuxiliares.h"
#include "Conductor.h"
#include "Vehiculo.h"
#define  NO_ENCONTRADO -1

void leerConductores(const char *nombArch, struct Conductor *conductores, int &numCond) {
    ifstream arch(nombArch,ios::in);
    if (!arch.is_open()) {
        cout << "Error al abrir el archivo" <<nombArch<< endl;
        exit(1);
    }
    //95822412,Lucia,Garcia,C5506
    numCond = 0;
    while (1) {
        arch>>conductores[numCond].dni;
        if (arch.eof()) break;
        arch.get();
        conductores[numCond].nombre = leerCadenaExacta(arch,',');
        conductores[numCond].apellido = leerCadenaExacta(arch,',');
        conductores[numCond].licencia = leerCadenaExacta(arch,'\n');
        conductores[numCond].infracciones = new Infraccion[10]{};
        numCond++;
    }
}

void pruebaLecturaConductores(struct Conductor *conductores, int numCond) {
    cout<<"CONDUCTORES"<<endl;
    struct Vehiculo v;
    for (int i = 0; i < numCond; i++) {
        cout<<left<<setw(10)<<conductores[i].dni<<setw(15)<<conductores[i].nombre
            <<setw(15)<<conductores[i].apellido<<setw(10)<<conductores[i].licencia;
        v = conductores[i].vehiculo;
        if (v.placa != nullptr)
            cout<<right<<setw(10)<<v.dni_propietario<<"  "<<left<<setw(10)<<v.placa
                <<v.marca_modelo;
        cout<<endl;
        pruebaLecturaInfracciones(conductores[i].infracciones,conductores[i].cantidad_infracciones);
    }
}

char *leerCadenaExacta(ifstream &arch, char delimitador){
    char buffer[150], *pt;
    arch.getline(buffer,150,delimitador);
    if(arch.eof())return nullptr;
    pt = new char[strlen(buffer)+1];
    strcpy(pt,buffer);
    return pt;
}

void leerVeiculos(const char *nombArch, struct Vehiculo *vehiculos, int &numVehic) {
    ifstream arch(nombArch,ios::in);
    if (!arch.is_open()) {
        cout << "Error al abrir el archivo" <<nombArch<< endl;
        exit(1);
    }
    //10076758,GCU985,Fiat Uno
    numVehic = 0;
    while (true) {
        arch>>vehiculos[numVehic].dni_propietario;
        if (arch.eof())break;
        arch.get();
        vehiculos[numVehic].placa = leerCadenaExacta(arch,',');
        vehiculos[numVehic].marca_modelo = leerCadenaExacta(arch,'\n');
        numVehic++;
    }
}

void pruebaLecturaVehiculos(struct Vehiculo *vehiculos, int numVehic) {
    cout<<"VEHICULOS"<<endl;
    for (int i = 0; i < numVehic; i++) {
        cout<<left<<setw(10)<<vehiculos[i].dni_propietario
            <<setw(10)<<vehiculos[i].placa
            <<setw(15)<<vehiculos[i].marca_modelo<<endl;
    }
}

void leerInfracciones(const char *nombArch, struct Infraccion *infraciones,int &numInfrac) {
    ifstream arch(nombArch,ios::in);
    if (!arch.is_open()) {
        cout << "Error al abrir el archivo" <<nombArch<< endl;
        exit(1);
    }
    // 24549543,17-06-2025,B2,NO RESPETAR SENAL,Muy Grave,200.0
    char c;
    int dd,mm,aa;
    numInfrac = 0;
    while (true) {
        arch>>infraciones[numInfrac].dni_conductor;
        if (arch.eof())break;
        arch>>c>>dd>>c>>mm>>c>>aa>>c;
        infraciones[numInfrac].fecha_infraccion.dd = dd;
        infraciones[numInfrac].fecha_infraccion.mm = mm;
        infraciones[numInfrac].fecha_infraccion.aa = aa;
        infraciones[numInfrac].fecha_infraccion.aammdd = aa*10000+mm*100+dd;
        infraciones[numInfrac].codigo=leerCadenaExacta(arch,',');
        infraciones[numInfrac].descripcion=leerCadenaExacta(arch,',');
        infraciones[numInfrac].gravedad=leerCadenaExacta(arch,',');
        arch>>infraciones[numInfrac].monto;
        if (infraciones[numInfrac].codigo[0]=='C') infraciones[numInfrac].monto *=1.2;
        numInfrac++;
    }
}

void pruebaLecturaInfracciones(struct Infraccion *infraciones, int numInfrac) {
    cout<<"Infraciciones"<<endl;
    cout.precision(2);
    cout<<fixed;
    for (int i = 0; i < numInfrac; i++) {
        cout<<right<<setw(10)<<infraciones[i].dni_conductor
            <<setw(10)<<infraciones[i].fecha_infraccion.aammdd
            <<"  "<<left<<setw(4)<<infraciones[i].codigo
            <<setw(30)<<infraciones[i].descripcion
            <<setw(10)<<infraciones[i].gravedad
            <<right<<setw(10)<<infraciones[i].monto<<endl;
    }
}

void actualizarInformacion(struct Conductor *conductores, int numCond,
                           struct Vehiculo *vehiculos, int numVehic,
                           struct Infraccion *infraciones, int numInfrac) {
    for (int i = 0; i < numCond; i++) {
        asignaVehiculo(conductores[i],vehiculos,numVehic);
        asignaInfracciones(conductores[i],infraciones,numInfrac);
    }
}

void asignaVehiculo(struct Conductor &conductor,
                    struct Vehiculo *vehiculos, int numVehic) {
    int pos;
    pos = buscarVehiculo(conductor.dni,vehiculos,numVehic);
    if (pos != NO_ENCONTRADO) {
        conductor.vehiculo.dni_propietario = vehiculos[pos].dni_propietario;
        copiarCadena(conductor.vehiculo.placa,vehiculos[pos].placa);
        copiarCadena(conductor.vehiculo.marca_modelo,vehiculos[pos].marca_modelo);
    }
}

int buscarVehiculo(int dni, struct Vehiculo *vehiculos, int numVehic) {
    for (int i = 0; i < numVehic; i++) {
        if (dni == vehiculos[i].dni_propietario) return i;
    }
    return NO_ENCONTRADO;
}

void copiarCadena(char *&destino, const char *fuente) {
    destino = new char[strlen(fuente)+1];
    strcpy(destino, fuente);
}

void asignaInfracciones(struct Conductor &conductor,
                        struct Infraccion *infraciones, int numInfrac) {
    int n;
    for (int i = 0; i < numInfrac; i++) {
        if (conductor.dni == infraciones[i].dni_conductor) {
            n = conductor.cantidad_infracciones;
            conductor.infracciones[n].fecha_infraccion =
                                           infraciones[i].fecha_infraccion;
            copiarCadena(conductor.infracciones[n].codigo,
                                                    infraciones[i].codigo);
            copiarCadena(conductor.infracciones[n].descripcion,
                                               infraciones[i].descripcion);
            copiarCadena(conductor.infracciones[n].gravedad,
                                                   infraciones[i].gravedad);
            conductor.infracciones[n].monto = infraciones[i].monto;
            conductor.infracciones[n].dni_conductor = infraciones[i].dni_conductor;
            conductor.cantidad_infracciones++;
        }
    }
}

void emitirPapeletas(struct Conductor *conductores, int numCond) {
    char nombreArchivo[60];
    for (int i = 0; i < numCond; i++) {
        creaNombreArchivio(nombreArchivo, conductores[i]);
        for (int inf=0; inf<conductores[i].cantidad_infracciones; inf++)
            creaPapeleta(nombreArchivo,conductores[i],inf);
    }
}

void creaNombreArchivio(char *nombreArchivo, const struct Conductor &conductor) {
    strcpy(nombreArchivo,"papeletas/");
    strcat(nombreArchivo,conductor.apellido);
    strcat(nombreArchivo,conductor.nombre);
    strcat(nombreArchivo,conductor.licencia);
    strcat(nombreArchivo,".txt");
}

void creaPapeleta(char *nombreArchivo,const struct Conductor &conductor,int inf){
    ofstream arch(nombreArchivo, ios::out);
    if (not arch.is_open()) {
        cout << "Error al abrir el archivo "<<nombreArchivo << endl;
        exit(1);
    }
    struct Infraccion infrac = conductor.infracciones[inf];

    arch<<"Fecha de infraccion: "<<setfill('0')<<setw(2)<<infrac.fecha_infraccion.dd
        <<'/'<<setw(2)<<infrac.fecha_infraccion.mm
        <<'/'<<setw(4)<<infrac.fecha_infraccion.aa<<setfill(' ')<<endl;
    arch<<right<<endl<<"Conductor:"<<endl;
    arch<<"  Nombres       : "<<conductor.nombre<<endl;
    arch<<"  Apellidos     : "<<conductor.apellido<<endl;
    arch<<"  DNI           : "<<conductor.dni<<endl;
    arch<<"  Licencia      : "<<conductor.licencia<<endl;

    arch<<endl<<"Vehiculo:"<<endl;
    arch<<"  Placa         : "<<conductor.vehiculo.placa<<endl;
    arch<<"  Marca/Modelo  : "<<conductor.vehiculo.marca_modelo<<endl;

    arch<<endl<<"Infraccion:"<<endl;
    arch<<"  Codigo        : "<<infrac.codigo<<endl;
    arch<<"  Descripcion   : "<<infrac.descripcion<<endl;
    arch<<"  Gravedad      : "<<infrac.gravedad<<endl;

    arch.precision(2);
    arch<<fixed;
    arch<<endl<<"Monto a Pagar: S/"<<setw(7)<<infrac.monto<<endl;
}


