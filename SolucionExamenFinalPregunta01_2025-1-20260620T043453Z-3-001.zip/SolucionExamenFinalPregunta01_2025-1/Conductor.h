// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  Conductor.h.h
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:46:48.
//

#ifndef CONDUCTOR_H
#define CONDUCTOR_H

#include  "Vehiculo.h"
#include  "Infraccion.h"

struct Conductor {
  int dni;
  char *nombre;
  char *apellido;
  char *licencia;
  struct Vehiculo vehiculo;
  struct Infraccion *infracciones;
  int cantidad_infracciones;
};

#endif //CONDUCTOR_H
