// Proyecto: SolucionExamenFinalPregunta01_2025_1
// Archivo:  FuncionesAuxiliares.h.h
//
// Autor:   J. Miguel Guanira E.
// Creado el lunes, 07 de julio del 2025 a las 10:52:50.
//

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void leerConductores(const char *nombArch, struct Conductor *conductores, int &numCond);
void leerVeiculos(const char *nombArch, struct Vehiculo *vehiculos, int &numVehic);
char *leerCadenaExacta(ifstream &arch, char delimitador);
void pruebaLecturaConductores(struct Conductor *conductores, int numCond);
void pruebaLecturaVehiculos(struct Vehiculo *vehiculos, int numVehic);
void leerInfracciones(const char *nombArch, struct Infraccion *infraciones,int &numInfrac);
void pruebaLecturaInfracciones(struct Infraccion *infraciones, int numInfrac);
void actualizarInformacion(struct Conductor *conductores, int numCond,
                           struct Vehiculo *vehiculos, int numVehic,
                           struct Infraccion *infraciones, int numInfrac);
void asignaVehiculo(struct Conductor &conductor,
                    struct Vehiculo *vehiculos, int numVehic);
int buscarVehiculo(int dni, struct Vehiculo *vehiculos, int numVehic);
void copiarCadena(char *&destino, const char *fuente);
void asignaInfracciones(struct Conductor &conductor,
                        struct Infraccion *infraciones, int numInfrac);
void emitirPapeletas(struct Conductor *conductores, int numCond);
void creaNombreArchivio(char *nombreArchivo, const struct Conductor &conductor);
void creaPapeleta(char *nombreArchivo,const struct Conductor &conductor,int inf);

#endif //FUNCIONESAUXILIARES_H
