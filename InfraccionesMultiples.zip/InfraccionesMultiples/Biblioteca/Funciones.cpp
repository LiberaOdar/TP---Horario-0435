//
// Created by cueva.r on 24/04/2026.
//
#include <iostream>
#include <iomanip>
#include <fstream>
#include "Funciones.h"

using namespace std;

void procesaarchivos(const char* nomempr,
                     const char* nominfr,
                     const char* nomtabla,
                     const char* nomrepo) {

    ifstream archempr(nomempr,ios::in);
    if (not archempr.is_open()) {
        cout << "Error al abrir archivo "<<nomempr << endl;
        exit(1);
    }
    ifstream archinfr(nominfr,ios::in);
    if (not archinfr.is_open()) {
        cout << "Error al abrir archivo "<<nominfr << endl;
        exit(1);
    }
    ifstream archtabla(nomtabla,ios::in);
    if (not archtabla.is_open()) {
        cout << "Error al abrir archivo "<<nomtabla << endl;
        exit(1);
    }
    ofstream repo(nomrepo,ios::out);
    if (not repo.is_open()) {
        cout << "Error al abrir archivo "<< nomrepo << endl;
        exit(1);
    }
    int dni,num1,num2;
    char tipo,c;
    // EmpresasRegistradas
    //79672079        contreras/chang/johana-cinthia     Chorrillos      P599-629        M852-620   P282-128
    while (true) {
        archempr >> dni;
        if (archempr.eof())break;
        leetexto(archempr,repo,' ');
        leetexto(archempr,repo,' ');
        while (true){
            archempr >> tipo >> num1 >>c>> num2;
            repo <<endl<< setw(4)<<"Placa:" << num1<<num2<<endl;
            leeinfracciones(tipo,num1,num2,archinfr,archtabla,repo);
            repo<< endl;
            if (archempr.get() == '\n')break;
        }
    }
}
// 1/12/2020   G760-721      G2022
// 23/7/2023      P474-593     G2060
void leeinfracciones(char tipo,int num1,int num2,ifstream&archinfr,
    ifstream &archtabla, ofstream &repo) {
    int fecha,dd,mm,aa,num1c,num2c,codinf,flag=0;
    char c,tipoc,gravedad;
    archinfr.clear();
    archinfr.seekg(0);
    repo <<endl;
    while (true) {
        fecha=leefechayhora(archinfr,dd,mm,aa);
        if (fecha==0)break;
        archinfr >> tipoc >> num1c >>c>> num2c;
        if (tipo==tipoc and num1==num1c and num2==num2c) {
            flag=1;
            archinfr >>gravedad>>codinf;
            repo<<setw(2)<<setfill('0') << dd<<"/"<<setw(2)<<mm<<"/"<<setw(2)<<aa<<setfill(' ')<<setw(4)<<" " ;
            leetabla(gravedad,codinf,archtabla,repo);
            repo<<endl;
        }
        else  while (archinfr.get()!='\n');
    }
    if (flag==0) repo<<"El vehiculo no tiene infracciones"<<endl;
}
// L3001     214.55        Dejar mal estacionado el vehiculo en lugares permitidos.
void leetabla(char gravedad,int codinf,ifstream&archtabla,
    ofstream &repo) {
    char gravedadc;
    int codinfc,flag=0;
    double monto;
    archtabla.clear();
    archtabla.seekg(0);
    while (true) {
        archtabla >> gravedadc;
        if (archtabla.eof())break;
        archtabla>> codinfc;
        if (gravedad==gravedadc and codinfc==codinf) {
            archtabla >>monto;
            leetexto(archtabla,repo,'\n');
            flag=1;
        }
        else while (archtabla.get()!='\n');
    }
    if (flag==0)
        repo << "No se encontro la infraccion"<<endl;

}

int leefechayhora(ifstream &arch,int &dd,int &mm,int &aa) {
    char c;
    arch>>dd;
    if (arch.eof()) return 0;
    arch>>c>>mm>>c>>aa;
    if (c=='/')
        return aa*10000+mm*100+dd;
    if (c==':')
        return dd*3600+mm*60+aa;
    return 0;
}


void leetexto(ifstream &arch,
    ofstream &repo,char delim) {
    int num=0;
    char c;
    arch>>ws;
    while (true) {
        c=arch.get();
        if (c==delim)break;
        if (c=='*' or c=='/' or c=='-')
            repo <<" ";
        else {
            if (c>='a' and c<='z')
                c=c-'a'+'A';
            repo<<c;
        }
        num++;
    }
    for(int i=0;i<60-num;i++)repo<<" ";
}