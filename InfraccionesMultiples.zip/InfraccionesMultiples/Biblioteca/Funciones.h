//
// Created by cueva.r on 24/04/2026.
//

#ifndef INFRACCIONESMULTIPLES_FUNCIONES_H
#define INFRACCIONESMULTIPLES_FUNCIONES_H
#include <fstream>
using namespace std;

void procesaarchivos(const char* nomempr,const char* nominfr, const char* nomtabla,
                     const char* nomrepo);
int leefechayhora(ifstream &arch,int &dd,int &mm,int &aa);
void leetexto(ifstream &arch, ofstream &repo,char delim);
void leetabla(char gravedad,int codinf,ifstream&archtabla,
    ofstream &repo);
void leeinfracciones(char tipo,int num1,int num2,ifstream&archinfr,
    ifstream &archtabla, ofstream &repo);
#endif //INFRACCIONESMULTIPLES_FUNCIONES_H