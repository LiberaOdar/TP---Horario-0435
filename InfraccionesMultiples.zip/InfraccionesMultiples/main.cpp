#include "Biblioteca/Funciones.h"

int main() {
    procesaarchivos("ArchivosEntrada/EmpresasRegistradas.txt",
        "ArchivosEntrada/InfraccionesCometidas.txt","ArchivosEntrada/TablaDeInfracciones.txt",
        "ArchivosSalida/Reporte.txt");

    return 0;
}