//
// Created by cueva.r on 29/04/2026.
//

#ifndef ARREGLOSSTREAM_FUNCIONES_H
#define ARREGLOSSTREAM_FUNCIONES_H
#include <fstream>
using namespace std;

int leefecha(ifstream &arch);
void cargacanales(int *canfecha,char *canletra,int *cancodigo,double *canrating,
    int *eticodeti,int *etitiempo,int *repfecha,
    char *repletra,int * repcodigo,int *repcodeti,int *repnum,int *cantiempo,int *canrepro,const char *nom1);
int leetiempo(ifstream &arch);
void cargaetiquetas(int *, int *, const char*);
void cargareproducciones(int *,char *,int *,
    int *,int *,const char *);


#endif //ARREGLOSSTREAM_FUNCIONES_H