//
// Created by cueva.r on 29/04/2026.
//

#include "Funciones.h"
#include <iomanip>
#include <iostream>
#include <fstream>
#define MAXCANALES 150
#define MAXETIQUETAS 125

using namespace std;
// 19/06/2022    X5514      xQcOW      2.5      632180
// 21/02/2023      S6846      summit1g      4.8      866146-380174-770185
// 06/01/2022      G2281      Gaules      3.93      501133-867160-614102-647182-570116-683126-323171
void cargacanales(int *canfecha,char *canletra,int *cancodigo,double *canrating,
    int *eticodeti,int *etitiempo,int *repfecha,
    char *repletra,int * repcodigo,int *repcodeti,int *repnum,
    int *cantiempo,int *canrepro,const char *nom1) {
    int codeti;
    int i=0;
    ifstream arch(nom1,ios::in);
    if (not arch.is_open()) {
        cout << "No se puede arbrir el archivo " << nom1 << endl;
    }
    while (true) {
        canfecha[i]=leefecha(arch);
        if (canfecha[i]==0)break; //if(arch.eof()) break;

        i++;
    }
}

// 4/02/2025      G2582      726131      390
// 30/01/2025      D8455      115115      300
void cargareproducciones(int *repfecha,char *repletra,int *repcodigo,
    int *repcodeti,int *etinumrep,const char *nom) {
    int i=0;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout << "No se puede arbrir el archivo " << nom << endl;
    }
    while (true) {
        repfecha[i]=leefecha(arch);
        if (repfecha[i]==0)break;
        arch >> repletra[i]>>repcodigo[i]>>repcodeti[i]>>etinumrep[i];
        i++;
    }
}
// 803100    dropsenabled   01:27
// 249101  chill   02:07

void cargaetiquetas(int *eticodeti, int *etitiempo, const char*nom) {
    int i=0;
    ifstream arch(nom,ios::in);
    if (not arch.is_open()) {
        cout << "No se puede arbrir el archivo " << nom << endl;
    }
    while (true) {
        arch >> eticodeti[i];
        if (arch.eof())break;
        arch>>ws;
        while (arch.get()!=' ');
        etitiempo[i]=leetiempo(arch);
        i++;
    }
}
int leetiempo(ifstream &arch) {
    int mm,ss;
    char c;
    arch>>mm>>c>>ss;
    return mm*60+ss;
}

int leefecha(ifstream &arch) {
    int dd,mm,aa;
    char c;
    arch>>dd;
    if (arch.eof()) return 0;
    arch>>c>>mm>>c>>aa;
    return aa*10000+mm*100+dd;
}