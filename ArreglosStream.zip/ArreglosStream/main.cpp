#include <iostream>

#include "Biblioteca/Funciones.h"
#define MAXCANALES 150
#define MAXETIQUETAS 125

int main() {
    int canfecha[MAXCANALES]{}, cancodigo[MAXCANALES]{},cantiempo[MAXCANALES]{},canrepro[MAXCANALES]{};
    int eticodeti[MAXETIQUETAS]{},etitiempo[MAXETIQUETAS]{},totaltiempo[MAXCANALES]{},totalrep[MAXCANALES]{};
    double canrating[MAXCANALES]{};
    char canletra[MAXCANALES],repletra[800];
    int repfecha[800]{},repcodigo[800]{},repcodeti[800]{},repnum[800]{};

    cargaetiquetas(eticodeti,etitiempo,"Etiquetas.txt");
    cargareproducciones(repfecha,repletra,repcodigo,repcodeti,repnum,"ReproduccionesDeEtiquetas.txt");
    cargacanales(canfecha,canletra,cancodigo,canrating,eticodeti,etitiempo,repfecha,repletra,repcodigo,repcodeti,repnum,
        cantiempo,canrepro,"Canales.txt");

    return 0;
}