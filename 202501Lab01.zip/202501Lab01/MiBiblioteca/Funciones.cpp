//
// Created by cueva.r on 1/04/2026.
//
#include <iomanip>
#include <iostream>
#include "Funciones.h"
#define ESP 10

using namespace  std;


void emitirreporte() {
    imprimecabecera();
}
void imprimecabecera(){
    cout << setw(80)<<"MINISTERIO DE TRANSPORTE"<<endl;
    cout << setw(85)<<"MULTAS IMPUESTAS A LAS COMPANIAS"<< endl;
    imprimelinea('=',120);
    imprimelinea('-',120);
}

void imprimelinea(char c,int n) {
    for(int i=0;i<n;i++)cout<<c;
    cout<<endl;
}

int leefecha(int &dd,int &mm,int &aa) {
    char c;
    cin>>dd>>c>>mm>>c>>aa;
    return aa*10000+mm*100+dd;
}
// Contreras/Chang/Johana-Cinthia
void leetexto(char delim) {
    int num=0;
    char c;
    cin>>ws;
    while (true) {
        c=cin.get();
        if (c==delim)break;
        if (c=='*' or c=='/' or c=='-')
            cout <<" ";
        else {
            if (c>='a' and c<='z')
                c=c-'a'+'A';
            cout<<c;
        }
        num++;
    }
    for(int i=0;i<60-num;i++)cout<<" ";
}

void leerdatos() {
    int di,df,mi,mf,ai,af,dni;
    int fechaini=leefecha(di,mi,ai);
    int fechafin=leefecha(df,mf,af);
    while (true) {
        cin >> dni;
        if (cin.eof())break;
        cout<<"Representante Legal: ";
        leetexto(' ');
        cout<<"DNI: "<<dni<<endl;
        leeinfracciones(fechaini,fechafin);
       // while (cin.get()!='\n');
    }

}
// P599-629    12/12/2023  10:42:26      L
void leeinfracciones(int fechaini,int fechafin) {
    char letra,c,grave;
    int num1,num2,aa,mm,dd,hh,mi,ss;

    while (true) {
        cin>>letra>>num1>>c>>num2;
        int fechaux=leefecha(dd,mm,aa);
        leefecha(hh,mi,ss);
        cin >> grave;
        if (fechaux<=fechafin and fechaini<=fechaux) {
            imprimedatosfijos(letra,num1,num2,dd,mm,aa,hh,mi,ss,grave);
            cout << endl;
        }
        if (cin.get()=='\n')break;
    }

}

void imprimedatosfijos(char letra,int num1,int num2,int dd,int mm,int aa,
    int hh, int mi,int ss,char grave ) {
    if (letra=='P')cout<<setfill(' ' ) <<left<<setw(10)<< "PEQUENO";
    if (letra=='M')cout <<setfill(' ' ) <<left<<setw(10)<< "MEDIANO";
    if (letra=='C')cout <<setfill(' ' ) <<left<<setw(10)<< "GRANDE";
    cout << setw(ESP)<<" "<<letra<<num1 <<num2<<setw(ESP)<<" ";
    cout <<right<<setfill('0')<< setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa<<setfill(' ' ) ;
    cout <<setw(ESP)<<" "<<setfill('0')<<setw(2)<<hh<<":"<<setw(2)<<mi<<":"<<setw(2)<<ss<<setfill(' ' ) ;
    if ('L'==grave) cout <<setw(2*ESP) << "LEVE";
    if ('G'==grave) cout <<setw(2*ESP) << "GRAVE";
    if ('M'==grave) cout <<setw(2*ESP) << "MUY GRAVE";
}
