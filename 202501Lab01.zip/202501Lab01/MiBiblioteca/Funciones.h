//
// Created by cueva.r on 1/04/2026.
//

#ifndef INC_202501LAB01_FUNCIONES_H
#define INC_202501LAB01_FUNCIONES_H

    void imprimecabecera();
    void emitirreporte();
    void imprimelinea(char ,int );
    void leetexto(char delim);
    int leefecha(int &dd,int &mm,int &aa);
    void leerdatos();
    void leeinfracciones(int,int);
    void imprimedatosfijos(char letra,int num1,int num2,int dd,int mm,int aa,
    int hh, int mi,int ss, char );
#endif //INC_202501LAB01_FUNCIONES_H